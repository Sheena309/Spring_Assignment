package com.spring;

public class PythonWorld implements PythonLanguage{

	private JavaLanguage java;
	
	public PythonWorld(JavaLanguage java){
		this.java=java;
	}
	
	@Override
	public String learningPython() {
		return "I am learning Python & "+java.learningJava();
	}

	
}

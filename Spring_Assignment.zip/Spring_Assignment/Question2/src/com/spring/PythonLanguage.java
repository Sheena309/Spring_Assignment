package com.spring;

public interface PythonLanguage {

	String learningPython();
	
}

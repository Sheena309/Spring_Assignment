package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
		PythonLanguage pl = (PythonLanguage)ctx.getBean("python");
		System.out.println(pl.learningPython());
		
		
	}

}

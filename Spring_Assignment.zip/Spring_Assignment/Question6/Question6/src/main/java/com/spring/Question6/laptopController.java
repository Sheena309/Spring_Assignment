package com.spring.Question6;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class laptopController {

	@Autowired
	laptopService service;
	
	@PostMapping("/add")
	public Laptop addlaptop(@RequestBody Laptop l) {
		System.out.println(l.toString());
	return service.addlaptop(l);
		
	}
}

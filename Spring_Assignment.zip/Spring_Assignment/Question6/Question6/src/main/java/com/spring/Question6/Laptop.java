package com.spring.Question6;

public class Laptop {

	private int price;
	private String brand;
	private String os;
	
	Laptop(){}

	public Laptop(int price, String brand, String os) {
		super();
		this.price = price;
		this.brand = brand;
		this.os = os;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	@Override
	public String toString() {
		return "Laptop [price=" + price + ", brand=" + brand + ", os=" + os + "]";
	}
	
	
}

package com.spring.Question6;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class laptopService {

	//Laptop laptop;
	
	public Laptop addlaptop( Laptop laptop) {
		
		return laptop;
		
	}
	
	
}

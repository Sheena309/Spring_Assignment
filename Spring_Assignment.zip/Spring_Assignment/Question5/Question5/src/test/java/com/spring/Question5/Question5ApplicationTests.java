package com.spring.Question5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question5ApplicationTests {

	@Test
	void contextLoads() {
	}

}

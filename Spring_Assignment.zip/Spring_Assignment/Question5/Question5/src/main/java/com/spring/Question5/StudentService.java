package com.spring.Question5;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class StudentService {

	Map map=new HashMap();
	
	
	public Map getStudents() {
		
		map.put("id", "101");
		map.put("name", "AAA");
		map.put("marks", "90");
		
		
		return map;
		
	}
	
	
}

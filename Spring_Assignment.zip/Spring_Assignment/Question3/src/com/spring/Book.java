package com.spring;

import org.springframework.stereotype.Component;

@Component("book")
public class Book {

	public String bookName() {
		return "The Great Gatsby";
	}
}

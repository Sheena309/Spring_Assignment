package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
		Book b = (Book)ctx.getBean("book");
		System.out.println(b.bookName());

	}

}

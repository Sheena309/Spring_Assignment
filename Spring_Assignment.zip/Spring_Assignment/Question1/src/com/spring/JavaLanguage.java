package com.spring;

public interface JavaLanguage {

	String learningJava();
}

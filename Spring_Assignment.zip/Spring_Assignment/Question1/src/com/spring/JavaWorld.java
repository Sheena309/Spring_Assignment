package com.spring;

import org.springframework.stereotype.Component;


public class JavaWorld implements JavaLanguage{

	
	public String learningJava() {
		
		return "I am learning Java";
	}

}
